import { NextRequest, NextResponse } from "next/server";
import { queryAI } from "@/lib/ai-providers";
import { getAllTools, callMcp, getServerDescriptions } from "@/lib/mcp-bridge";
import { getSession } from "@/lib/auth";

type ToolCallArgs = Record<string, unknown>;

function formatCourses(data: any[]): string {
  if (!Array.isArray(data) || data.length === 0) return "No courses found.";
  let md = "📚 **Your Enrolled Courses:**\n\n";
  for (const c of data) {
    const gradeStr = c.grade ? ` — Grade: **${c.grade}**` : " — _In Progress_";
    md += `**${c.code}: ${c.name}**${gradeStr}\n`;
    md += `- 👨‍🏫 ${c.instructor} | 🕐 ${c.schedule}\n`;
    md += `- 📍 ${c.location}, ${c.building} | Credits: ${c.credits}\n\n`;
  }
  return md;
}

function formatSchedule(data: any): string {
  const courses = data?.schedule || data;
  if (!Array.isArray(courses) || courses.length === 0) return "No schedule found.";
  let md = "🗓️ **Your Weekly Schedule:**\n\n";
  for (const c of courses) {
    md += `- **${c.code} — ${c.name}**: ${c.schedule} at ${c.location} (${c.building})\n`;
  }
  return md;
}

function formatBooks(data: any[]): string {
  if (!Array.isArray(data) || data.length === 0) return "No books found.";
  let md = "📖 **Available Library Books:**\n\n";
  for (const b of data.slice(0, 8)) {
    const status = b.available_copies > 0 ? `✅ ${b.available_copies} available` : "❌ All checked out";
    md += `**${b.title}** by ${b.author}\n`;
    md += `- Genre: ${b.genre} | ${status}\n\n`;
  }
  return md;
}

function formatMeal(data: any): string {
  if (!data) return "No meal information available.";
  const items = data.items || [];
  let md = `🍽️ **Current Meal — ${(data.currentMeal || "").charAt(0).toUpperCase() + (data.currentMeal || "").slice(1)}** (${data.day || "today"})\n\n`;
  if (items.length === 0) {
    md += "_No items on the menu right now._\n";
  } else {
    for (const item of items) {
      const tags = [];
      if (item.is_vegetarian) tags.push("🥬 Vegetarian");
      if (item.is_vegan) tags.push("🌱 Vegan");
      md += `- **${item.item_name}** (${item.category}) — $${item.price} | ${item.calories} cal`;
      if (tags.length > 0) md += ` | ${tags.join(", ")}`;
      md += `\n`;
    }
  }
  if (data.time) md += `\n_Menu as of ${data.time}_`;
  return md;
}

function formatEvents(data: any[]): string {
  if (!Array.isArray(data) || data.length === 0) return "No upcoming events found.";
  let md = "🎉 **Upcoming Campus Events:**\n\n";
  for (const e of data) {
    const dateStr = new Date(e.date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
    const spots = e.max_attendees ? ` | ${e.max_attendees - e.current_attendees} spots left` : "";
    const free = e.is_free ? "🆓 Free" : "💰 Paid";
    md += `**${e.title}**\n`;
    md += `- 📅 ${dateStr}, ${e.time}–${e.end_time} | 📍 ${e.location}, ${e.building}\n`;
    md += `- ${free}${spots} | Organized by: ${e.organizer}\n`;
    md += `- _${e.description}_\n\n`;
  }
  return md;
}

function formatAlerts(data: any[]): string {
  if (!Array.isArray(data) || data.length === 0) return "No active alerts.";
  const severityEmoji: Record<string, string> = { urgent: "🔴", warning: "🟡", info: "🔵" };
  let md = "📢 **Campus Alerts & Announcements:**\n\n";
  for (const a of data) {
    const emoji = severityEmoji[a.severity] || "ℹ️";
    md += `${emoji} **${a.title}**\n`;
    md += `- ${a.message}\n`;
    md += `- _By ${a.author}${a.expiry_date ? ` • Expires: ${a.expiry_date}` : ""}_\n\n`;
  }
  return md;
}

const RPC_URLS: Record<string, string> = {
  library: process.env.MCP_LIBRARY_URL || "http://127.0.0.1:4001",
  cafeteria: process.env.MCP_CAFETERIA_URL || "http://127.0.0.1:4002",
  events: process.env.MCP_EVENTS_URL || "http://127.0.0.1:4003",
  academics: process.env.MCP_ACADEMICS_URL || "http://127.0.0.1:4004",
  notifications: process.env.MCP_NOTIFICATIONS_URL || "http://127.0.0.1:4005",
};

async function callRpc(server: string, method: string, params: Record<string, unknown> = {}): Promise<any> {
  const url = RPC_URLS[server];
  if (!url) throw new Error(`Unknown server: ${server}`);
  const res = await fetch(`${url}/rpc`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", method, params, id: 1 }),
  });
  if (!res.ok) throw new Error(`RPC call to ${server}/${method} failed: ${res.status}`);
  const json = await res.json();
  return json.result;
}

async function queryCampusData(query: string, studentId?: string) {
  const q = query.toLowerCase();

  try {
    // Library
    if (q.includes("book") || q.includes("library") || q.includes("algorithm") || q.includes("available") || q.includes("borrow") || q.includes("hold")) {
      const searchTerm = q.match(/["']([^"']+)["']|(?:book|find|search)\s+(.+)/i)?.[1] || q.replace(/is|the|available|find|search|book|library/g, "").trim() || "a";
      const data = await callRpc("library", "search_books", { query: searchTerm });
      return { answer: formatBooks(Array.isArray(data) ? data : []), sources: ["library"] };
    }

    // Courses / schedule
    if (q.includes("course") || q.includes("grade") || q.includes("class") || q.includes("acad") || q.includes("cs101") || q.includes("cs201") || q.includes("exam") || q.includes("policy")) {
      // Extract course code if mentioned
      const courseMatch = q.match(/\b([a-z]{2,4}\d{3})\b/i);
      if (courseMatch) {
        const data = await callRpc("academics", "get_course_details", { courseCode: courseMatch[1].toUpperCase() });
        const course = data as any;
        if (course && !course.error) {
          return {
            answer: `📚 **${course.code} — ${course.name}**\n\n👨‍🏫 Instructor: ${course.instructor}\n📍 Location: ${course.location}, ${course.building}\n⏰ Schedule: ${course.schedule}\n💡 ${course.description}\n\n📋 **Spots remaining:** ${course.spotsRemaining} of ${course.max_enrollment}`,
            sources: ["academics"],
          };
        }
      }
      const data = await callRpc("academics", "get_student_courses", { studentId: studentId || "STU001" });
      return { answer: formatCourses(Array.isArray(data) ? data : []), sources: ["academics"] };
    }

    if (q.includes("schedule") || q.includes("timetable") || q.includes("when") || q.includes("time")) {
      const data = await callRpc("academics", "get_student_schedule", { studentId: studentId || "STU001" });
      return { answer: formatSchedule(data), sources: ["academics"] };
    }

    // Cafeteria
    if (q.includes("food") || q.includes("menu") || q.includes("cafeteria") || q.includes("meal") || q.includes("lunch") || q.includes("dinner") || q.includes("breakfast") || q.includes("eat")) {
      const data = await callRpc("cafeteria", "get_current_meal", {});
      return { answer: formatMeal(data), sources: ["cafeteria"] };
    }

    // Events
    if (q.includes("event") || q.includes("workshop") || q.includes("activity") || q.includes("happening") || q.includes("fest") || q.includes("rsvp") || q.includes("tech") || q.includes("conference")) {
      const data = await callRpc("events", "get_upcoming_events", { limit: 6 });
      return { answer: formatEvents(Array.isArray(data) ? data : []), sources: ["events"] };
    }

    // Notifications / Alerts
    if (q.includes("alert") || q.includes("notification") || q.includes("announce") || q.includes("deadline") || q.includes("urgent") || q.includes("news")) {
      const [alerts, deadlines] = await Promise.all([
        callRpc("notifications", "get_pinned_alerts", {}),
        callRpc("notifications", "get_upcoming_deadlines", { days: 14 }),
      ]);
      const alertText = formatAlerts(Array.isArray(alerts) ? alerts : []);
      const dlText = Array.isArray(deadlines) && deadlines.length > 0
        ? `\n\n📅 **Upcoming Deadlines:**\n${deadlines.slice(0, 3).map((d: any) => `• **${d.title}** — Due ${d.due_date}${d.course_code ? ` (${d.course_code})` : ""}`).join("\n")}`
        : "";
      return { answer: alertText + dlText, sources: ["notifications"] };
    }

    // Default: show current campus highlights
    const [alerts, events, meal] = await Promise.all([
      callRpc("notifications", "get_pinned_alerts", {}).catch(() => []),
      callRpc("events", "get_upcoming_events", { limit: 2 }).catch(() => []),
      callRpc("cafeteria", "get_current_meal", {}).catch(() => null),
    ]);

    const parts: string[] = ["👋 **Hey there! Here's what's happening on campus:**\n"];
    if (Array.isArray(alerts) && alerts.length > 0) parts.push(`🔔 **Campus Alert:** ${alerts[0].title} — ${alerts[0].message}`);
    if (meal) parts.push(`🍽️ **Today's ${meal.currentMeal}:** ${(meal.items || []).slice(0, 2).map((i: any) => i.item_name).join(", ")}`);
    if (Array.isArray(events) && events.length > 0) parts.push(`🎉 **Upcoming:** ${events[0].title} on ${events[0].date} at ${events[0].time}`);
    parts.push("\n_Ask me about courses, the menu, events, library books, or campus alerts!_");
    return { answer: parts.join("\n"), sources: ["notifications", "cafeteria", "events"] };
  } catch (error: any) {
    console.error("queryCampusData RPC error:", error.message);
    return {
      answer: "⚠️ Sorry, I couldn't connect to the campus servers right now. Please make sure the MCP servers are running (`node start.js --dev`).",
      sources: [],
    };
  }
}

export async function POST(req: NextRequest) {
  try {
    const { query } = await req.json();

    if (!query || typeof query !== "string") {
      return NextResponse.json({ error: "Query is required" }, { status: 400 });
    }

    // Get student context for personalization
    const session = await getSession();
    const studentContext = session
      ? `\nThe current student is: ${session.name} (ID: ${session.studentId}, Major: ${session.major}, Year: ${session.year}). When they ask about "my courses" or "my schedule", use their student ID.`
      : "";

    const systemPrompt = `You are a helpful and friendly campus assistant for Campus Hub. Your job is to help students find information from various campus services.

Available data sources (MCP servers):
${getServerDescriptions()}
${studentContext}

Guidelines:
- Analyze the user's query and determine which data source(s) would be most helpful
- Use the appropriate tools to get real-time information
- Format your responses in a friendly, easy-to-read way using markdown
- Use bullet points, bold text, and emojis where appropriate to make info scannable
- If multiple sources are relevant, query all of them
- Always provide actionable information (locations, times, availability)
- Be concise but thorough`;

    const tools = await getAllTools();

    const callToolWrapper = async (server: string, toolName: string, args: ToolCallArgs) => {
      const result = await callMcp(server, toolName, args);
      let rawData;
      if (Array.isArray(result) && result.length > 0 && result[0].type === "text") {
        rawData = result[0].text;
      } else {
        rawData = JSON.stringify(result);
      }
      return `Here is the raw data found from the ${server} server: ${rawData}. Synthesize this into a natural sentence for the user.`;
    };

    const response = await queryAI(systemPrompt, query, tools, callToolWrapper);
    if (response.toolCalls.length === 0 && response.answer.includes("Both AI providers are unavailable")) {
      const fallback = await queryCampusData(query, session?.studentId);
      return NextResponse.json({ ...fallback, actions: deriveActions(fallback.sources || [], query) });
    }

    const sources = [...new Set(response.toolCalls.map((tc) => tc.server))];

    // Extract any entity IDs from tool call arguments for action payloads
    const actionPayloads: Record<string, any> = {};
    for (const tc of response.toolCalls) {
      if (tc.server === "events" && tc.args?.eventId) actionPayloads.eventId = tc.args.eventId;
      if (tc.server === "library" && tc.args?.bookId) actionPayloads.bookId = tc.args.bookId;
      if (tc.server === "cafeteria" && tc.args?.itemId) actionPayloads.itemId = tc.args.itemId;
      if (tc.server === "notifications" && tc.args?.announcementId) actionPayloads.announcementId = tc.args.announcementId;
    }

    return NextResponse.json({
      answer: response.answer,
      sources,
      actions: deriveActions(sources, query, actionPayloads),
    });
  } catch (error: unknown) {
    console.error("Chat API error:", error);
    const message = error instanceof Error ? error.message : String(error);
    return NextResponse.json(
      { error: "Failed to process query", message },
      { status: 500 }
    );
  }
}

type ActionType = 'rsvp' | 'hold' | 'favorite' | 'bookmark' | 'add_to_calendar' | 'set_dietary_alert';
interface ChatAction {
  type: ActionType;
  label: string;
  payload?: Record<string, unknown>;
}

function deriveActions(sources: string[], query: string, payload: Record<string, any> = {}): ChatAction[] {
  const actions: ChatAction[] = [];
  const q = query.toLowerCase();

  if (sources.includes("events")) {
    actions.push({ type: "rsvp", label: "✅ RSVP to Event", payload: { eventId: payload.eventId } });
    actions.push({ type: "add_to_calendar", label: "📅 Add to Calendar", payload: {} });
  }
  if (sources.includes("library")) {
    actions.push({ type: "hold", label: "📚 Place a Hold", payload: { bookId: payload.bookId } });
  }
  if (sources.includes("cafeteria")) {
    actions.push({ type: "favorite", label: "❤️ Mark Favorite", payload: { itemId: payload.itemId } });
    if (q.includes("diet") || q.includes("vegan") || q.includes("allerg") || q.includes("vegetar")) {
      actions.push({ type: "set_dietary_alert", label: "🔔 Set Dietary Alert", payload: {} });
    }
  }
  if (sources.includes("notifications") || sources.includes("academics")) {
    actions.push({ type: "bookmark", label: "🔖 Bookmark", payload: { announcementId: payload.announcementId } });
  }

  return actions;
}

