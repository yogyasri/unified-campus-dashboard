import { GoogleGenerativeAI } from "@google/generative-ai";

let _genAI: GoogleGenerativeAI | null = null;

function getGenAI(): GoogleGenerativeAI {
  const key = (process.env.GEMINI_API_KEY || "dummy-key").replace(/['"]/g, "");
  if (!_genAI) {
    _genAI = new GoogleGenerativeAI(key);
  }
  return _genAI;
}

export interface AITool {
  server: string;
  name: string;
  description: string;
  inputSchema: any;
}

export interface AIResponse {
  answer: string;
  toolCalls: Array<{ server: string; tool: string; args: any }>;
}

function convertJsonSchemaToGemini(schema: any): any {
  if (!schema || !schema.properties) return { type: "OBJECT", properties: {} };

  const properties: any = {};
  for (const [key, value] of Object.entries(schema.properties as Record<string, any>)) {
    const prop: any = { description: value.description || "" };
    switch (value.type) {
      case "string": prop.type = "STRING"; break;
      case "number":
      case "integer": prop.type = "NUMBER"; break;
      case "boolean": prop.type = "BOOLEAN"; break;
      case "array": prop.type = "ARRAY"; break;
      default: prop.type = "STRING";
    }
    properties[key] = prop;
  }

  return {
    type: "OBJECT",
    properties,
    required: schema.required || [],
  };
}

export async function queryGemini(
  systemPrompt: string,
  userQuery: string,
  tools: AITool[],
  callTool: (server: string, toolName: string, args: any) => Promise<any>
): Promise<AIResponse> {
  const genAI = getGenAI();

  const functionDeclarations = tools.map((tool) => ({
    name: `${tool.server}__${tool.name}`,
    description: tool.description,
    parameters: convertJsonSchemaToGemini(tool.inputSchema),
  }));

  console.log(`[Gemini] Using API key: ${(process.env.GEMINI_API_KEY || "").substring(0, 8)}...`);
  console.log(`[Gemini] Sending query: "${userQuery}" with ${functionDeclarations.length} tools`);

  const model = genAI.getGenerativeModel({
    model: "gemini-2.0-flash",
    systemInstruction: systemPrompt,
    tools: [{ functionDeclarations }],
  });

  const chat = model.startChat();

  let result;
  try {
    result = await chat.sendMessage(userQuery);
  } catch (err: any) {
    console.error(`[Gemini] sendMessage failed:`, err?.message || err);
    console.error(`[Gemini] Full error:`, JSON.stringify(err, null, 2));
    throw err;
  }

  const response = result.response;

  const toolCallResults: Array<{ server: string; tool: string; args: any }> = [];
  const functionCalls = response.functionCalls();

  if (functionCalls && functionCalls.length > 0) {
    console.log(`[Gemini] AI requested ${functionCalls.length} tool call(s): ${functionCalls.map(fc => fc.name).join(", ")}`);
    const functionResponses: any[] = [];

    for (const fc of functionCalls) {
      const [serverName, toolName] = fc.name.split("__");
      const args = fc.args || {};
      toolCallResults.push({ server: serverName, tool: toolName, args });

      try {
        const toolResult = await callTool(serverName, toolName, args);
        functionResponses.push({
          functionResponse: {
            name: fc.name,
            response: { result: typeof toolResult === "string" ? toolResult : JSON.stringify(toolResult) },
          },
        });
      } catch (error: any) {
        console.error(`[Gemini] Tool call ${fc.name} failed:`, error.message);
        functionResponses.push({
          functionResponse: {
            name: fc.name,
            response: { error: error.message },
          },
        });
      }
    }

    const finalResult = await chat.sendMessage(functionResponses);
    const finalText = finalResult.response.text();
    console.log(`[Gemini] Final response length: ${finalText?.length || 0} chars`);

    return {
      answer: finalText || "I couldn't generate a response.",
      toolCalls: toolCallResults,
    };
  }

  const textResponse = response.text();
  console.log(`[Gemini] Direct response (no tools): ${textResponse?.substring(0, 100)}...`);

  return {
    answer: textResponse || "I couldn't generate a response.",
    toolCalls: [],
  };
}

