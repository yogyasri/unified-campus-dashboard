import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || "dummy-key",
});

export interface AITool {
  server: string;
  name: string;
  description: string;
  inputSchema: any;
}

export interface AIResponse {
  answer: string;
  toolCalls: Array<{ server: string; tool: string; args: any }>;
}

export async function queryOpenAI(
  systemPrompt: string,
  userQuery: string,
  tools: AITool[],
  callTool: (server: string, toolName: string, args: any) => Promise<any>
): Promise<AIResponse> {
  const formattedTools = tools.map((tool) => ({
    type: "function" as const,
    function: {
      name: `${tool.server}__${tool.name}`,
      description: tool.description,
      parameters: tool.inputSchema,
    },
  }));

  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userQuery },
    ],
    tools: formattedTools,
    tool_choice: "auto",
  });

  const assistantMessage = response.choices[0].message;
  const toolCallResults: Array<{ server: string; tool: string; args: any }> = [];

  if (assistantMessage.tool_calls && assistantMessage.tool_calls.length > 0) {
    const toolMessages: any[] = [];

    for (const toolCall of assistantMessage.tool_calls) {
      const [serverName, toolName] = toolCall.function.name.split("__");
      const args = JSON.parse(toolCall.function.arguments);
      toolCallResults.push({ server: serverName, tool: toolName, args });

      try {
        const result = await callTool(serverName, toolName, args);
        toolMessages.push({
          role: "tool" as const,
          tool_call_id: toolCall.id,
          content: typeof result === "string" ? result : JSON.stringify(result),
        });
      } catch (error: any) {
        toolMessages.push({
          role: "tool" as const,
          tool_call_id: toolCall.id,
          content: JSON.stringify({ error: error.message }),
        });
      }
    }

    const finalResponse = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userQuery },
        assistantMessage,
        ...toolMessages,
      ],
    });

    return {
      answer: finalResponse.choices[0].message.content || "I couldn't generate a response.",
      toolCalls: toolCallResults,
    };
  }

  return {
    answer: assistantMessage.content || "I couldn't generate a response.",
    toolCalls: [],
  };
}
