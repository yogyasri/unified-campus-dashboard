import { queryOpenAI, type AITool, type AIResponse } from "./openai";
import { queryGemini } from "./gemini";

export type { AITool, AIResponse };

type AIProvider = "openai" | "gemini";

function hasUsableApiKey(provider: AIProvider): boolean {
  const key = provider === "openai" ? process.env.OPENAI_API_KEY : process.env.GEMINI_API_KEY;
  if (!key) return false;
  return !key.startsWith("your-") && key !== "dummy-key";
}

function getProvider(): AIProvider {
  let provider = (process.env.AI_PROVIDER || "openai").toLowerCase();
  provider = provider.replace(/['"]/g, ""); // Strip quotes
  if (provider === "gemini") return "gemini";
  return "openai";
}

/**
 * Query the configured AI provider with tools
 * Automatically falls back to the other provider on failure
 * On rate-limit (429 / RESOURCE_EXHAUSTED) falls back immediately to direct RPC
 */
export async function queryAI(
  systemPrompt: string,
  userQuery: string,
  tools: AITool[],
  callTool: (server: string, toolName: string, args: Record<string, unknown>) => Promise<unknown>
): Promise<AIResponse> {
  const primary = getProvider();
  const fallback = primary === "openai" ? "gemini" : "openai";

  if (!hasUsableApiKey(primary) && !hasUsableApiKey(fallback)) {
    return {
      answer: "Both AI providers are unavailable. Please check your API keys.",
      toolCalls: [],
    };
  }

  function isRateLimit(err: unknown): boolean {
    const msg = (err instanceof Error ? err.message : String(err)).toLowerCase();
    return (
      msg.includes("429") ||
      msg.includes("resource_exhausted") ||
      msg.includes("rate limit") ||
      msg.includes("quota") ||
      msg.includes("too many requests")
    );
  }

  try {
    if (primary === "gemini" && hasUsableApiKey("gemini")) {
      return await queryGemini(systemPrompt, userQuery, tools, callTool);
    }
    if (primary === "openai" && hasUsableApiKey("openai")) {
      return await queryOpenAI(systemPrompt, userQuery, tools, callTool);
    }
    throw new Error(`${primary} API key is not configured`);
  } catch (primaryError) {
    // On rate limit, skip the fallback AI and return a signal to use direct RPC
    if (isRateLimit(primaryError)) {
      console.warn(`[AI] Rate limit hit on ${primary}. Switching to direct RPC fallback.`);
      return {
        answer: "Both AI providers are unavailable",
        toolCalls: [],
      };
    }

    console.error(`Primary AI provider (${primary}) failed:`, primaryError);

    // Attempt fallback AI provider
    try {
      console.log(`Falling back to ${fallback}...`);

      if (fallback === "gemini" && hasUsableApiKey("gemini")) {
        return await queryGemini(systemPrompt, userQuery, tools, callTool);
      }
      if (fallback === "openai" && hasUsableApiKey("openai")) {
        return await queryOpenAI(systemPrompt, userQuery, tools, callTool);
      }
      throw new Error(`${fallback} API key is not configured`);
    } catch (fallbackError) {
      if (isRateLimit(fallbackError)) {
        console.warn(`[AI] Rate limit hit on ${fallback} too. Using direct RPC fallback.`);
      } else {
        console.error("Fallback AI provider also failed:", fallbackError);
      }
      return {
        answer: "Both AI providers are unavailable",
        toolCalls: [],
      };
    }
  }
}
